package main

/**
komentar
multi line
tidak terbatas
 */
func main() {
	// Ini komentar single line
}

