package other

import "fmt"

func SayHello(name string){
	fmt.Println("Hello", name)
}
